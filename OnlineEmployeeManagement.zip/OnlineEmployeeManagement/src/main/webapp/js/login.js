const loginBtn = document.getElementById("login-btn");
const background = document.querySelector(".background");

loginBtn.addEventListener("click", function() {
  background.style.display = "block";
});